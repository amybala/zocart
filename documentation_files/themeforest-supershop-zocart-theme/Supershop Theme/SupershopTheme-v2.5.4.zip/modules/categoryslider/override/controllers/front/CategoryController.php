<?php

class CategoryController extends CategoryControllerCore
{
}