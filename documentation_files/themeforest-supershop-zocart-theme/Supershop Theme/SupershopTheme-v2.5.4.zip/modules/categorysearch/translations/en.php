<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{categorysearch}prestashop>categorysearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{categorysearch}prestashop>categorysearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Adds a quick search field to your website.';
$_MODULE['<{categorysearch}prestashop>categorysearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{categorysearch}prestashop>categorysearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Search products:';
$_MODULE['<{categorysearch}prestashop>categorysearch_5f075ae3e1f9d0382bb8c4632991f96f'] = 'Go';
