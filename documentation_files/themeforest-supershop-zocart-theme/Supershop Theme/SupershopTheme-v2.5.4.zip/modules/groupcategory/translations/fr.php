<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_c3ae9f07ec41596ed7759c55b9eb77db'] = 'Mise en page [défaut]';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_036ba5069bb8677e6d2b8e73b447aa29'] = 'Meilleure saller';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_4c957e41cb0c8ddabe9064e2856f3ef2'] = 'Plus vue';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_d1aa22a3126f04664e0fe3f598994014'] = 'Promos';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_31d26a6487e08357bd771619e894b0c6'] = 'Nouveautés';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_6bb68d3e5359934490b94876fe87ff31'] = 'Module Catégorie Ovic Groupe';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Vente';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_6a5373df703ab2827a4ba7facdfcf779'] = 'Ajouter à la liste';
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_36ca795d076169d7146af8b7d37abcdf'] = 'Aucun article de produit.';
$_MODULE['<{groupcategory}prestashop>groupcategory_036ba5069bb8677e6d2b8e73b447aa29'] = 'Best Saller fr';
$_MODULE['<{groupcategory}prestashop>groupcategory_900150983cd24fb0d6963f7d28e17f72'] = 'abc fr';
