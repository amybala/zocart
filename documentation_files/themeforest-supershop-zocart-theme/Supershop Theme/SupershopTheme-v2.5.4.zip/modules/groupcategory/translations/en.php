<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{groupcategory}prestashop>groupcategory-no-gen_036ba5069bb8677e6d2b8e73b447aa29'] = 'Best Saller en';
$_MODULE['<{groupcategory}prestashop>groupcategory_900150983cd24fb0d6963f7d28e17f72'] = 'abc en';
