<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{discountproducts}nella>discountproducts_home_fa58c0571ea091bf0b5087b5595083fc'] = 'Offres Du Jour';
$_MODULE['<{discountproducts}nella>discountproducts_home_9bfeb3137040a53fb79b8ab0f43cedaf'] = 'Se Termine Dans';
