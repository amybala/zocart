<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscatalog}blanktheme>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = 'Statistiques catalogue';
$_MODULE['<{statscatalog}blanktheme>statscatalog_08a7c3cf820979d2c8d4de4f47abb5e6'] = 'Ajoute un onglet contenant des statistiques générales sur votre catalogue dans le tableau de bord des statistiques.';
$_MODULE['<{statscatalog}blanktheme>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 achat / %d visites)';
$_MODULE['<{statscatalog}blanktheme>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = 'Choisissez une catégorie';
$_MODULE['<{statscatalog}blanktheme>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{statscatalog}blanktheme>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = 'Produits disponibles :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_1099377f1598a0856e2457a5145d89c2'] = 'Prix moyen (HT) :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = 'Pages produit vues :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = 'Produits commandés :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = 'Nombre moyen de visites :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = 'Nombre moyen d\'achats :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_c09d09e371989d89847049c9574b6b8e'] = 'Images disponibles :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_65275d1b04037d8c8e42425002110363'] = 'Nombre moyen d\'images :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_51b8891d531ad91128ba58c8928322ab'] = 'Produits jamais consultés :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = 'Produits jamais achetés :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = 'Taux de transformation* :';
$_MODULE['<{statscatalog}blanktheme>statscatalog_082d537edb8c61539b9f266eb331c88e'] = 'Défini le taux de transformation moyen pour une page produit. Un produit pouvant être acheté sans passer par sa page dédiée, cet indicateur peut être supérieur à 1.';
$_MODULE['<{statscatalog}blanktheme>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = 'Produits jamais achetés';
$_MODULE['<{statscatalog}blanktheme>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statscatalog}blanktheme>statscatalog_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statscatalog}blanktheme>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = 'Modifier / Afficher';
$_MODULE['<{statscatalog}blanktheme>statscatalog_7dce122004969d56ae2e0245cb754d35'] = 'Modifier';
$_MODULE['<{statscatalog}blanktheme>statscatalog_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';
