<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Bloc CMS d\'information client';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Ajoute un bloc d\'information client sur votre boutique.';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Une erreur est survenue lors de la sauvegarde';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nouveau bloc CMS';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texte';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Retour à la liste';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Identifiant du bloc';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Texte du bloc';
$_MODULE['<{blockcmsinfo}blanktheme>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Ajouter';
