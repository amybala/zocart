<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{imagesearchblock}blanktheme>imagesearchblock_9f5afc499e055dc78924487d95c09af9'] = 'Adds a quick search block.';
$_MODULE['<{imagesearchblock}blanktheme>imagesearchblock_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{imagesearchblock}blanktheme>imagesearchblock_52d578d063d6101bbdae388ece037e60'] = 'Enter a product name';
$_MODULE['<{imagesearchblock}blanktheme>imagesearchblock_34d1f91fb2e514b8576fab1a75a89a6b'] = 'go';
