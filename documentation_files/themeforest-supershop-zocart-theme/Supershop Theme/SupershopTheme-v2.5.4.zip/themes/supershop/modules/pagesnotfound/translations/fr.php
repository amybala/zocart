<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pages introuvables';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Ajoute un onglet au tableau de bord de statistiques, affichant les pages demandées par vos visiteurs mais qui n\'ont pas été trouvées.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'Le cache \"pages introuvables\" a été vidé.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'Le cache \"pages introuvables\" a été effacé.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'Erreurs 404';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Comment attraper ces erreurs ?';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Si votre hébergeur autorise les fichiers .htaccess, vous pouvez en créer un à la racine de votre PrestaShop et insérer la ligne suivante : \"%s\".';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Un utilisateur demandant une page qui n\'existe pas sera renvoyé vers la page suivante : %s. Ce module note les accès à cette page.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'Vous devez utiliser un fichier .htaccess pour renvoyer les erreurs 404 vers la page \"404.php\".';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Page';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Origine';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Compteur';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'Aucun problème de type \"page introuvable\" pour le moment.';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Suppression';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Vider toutes les mentions \"pages introuvables\" pour cette intervalle de temps';
$_MODULE['<{pagesnotfound}blanktheme>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Vider toutes les mentions \"pages introuvables';
