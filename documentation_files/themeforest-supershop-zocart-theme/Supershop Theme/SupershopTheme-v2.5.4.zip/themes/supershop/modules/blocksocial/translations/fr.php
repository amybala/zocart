<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksocial}blanktheme>blocksocial_3c3fcc2aa9705117ce4b589ed5a72853'] = 'Bloc social';
$_MODULE['<{blocksocial}blanktheme>blocksocial_094d3ac865853e0be9ba42e80f0f7ee7'] = 'Permet d\'ajouter des informations supplémentaires concernant les réseaux sociaux de votre marque.';
$_MODULE['<{blocksocial}blanktheme>blocksocial_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocksocial}blanktheme>blocksocial_76f8961bb8f4bb2b95c07650f30a7e7b'] = 'URL Facebook';
$_MODULE['<{blocksocial}blanktheme>blocksocial_c162369096f0fe5784f05052ceee6b47'] = 'Votre page de fan Facebook.';
$_MODULE['<{blocksocial}blanktheme>blocksocial_bcca29e10968edaf6e0154d2339ad556'] = 'URL Twitter';
$_MODULE['<{blocksocial}blanktheme>blocksocial_1a530e4877d8d41f810d9d05f065722d'] = 'URL de flux RSS';
$_MODULE['<{blocksocial}blanktheme>blocksocial_672f301ddc5372b2477ed3c1d9322949'] = 'Le flux RSS de votre choix (votre blog, votre boutique, etc.).';
$_MODULE['<{blocksocial}blanktheme>blocksocial_ad7198d676478ac70c3243c1d3446331'] = 'URL YouTube';
$_MODULE['<{blocksocial}blanktheme>blocksocial_5817a34292f074f9f596de6cb3607540'] = 'Votre compte officiel YouTube.';
$_MODULE['<{blocksocial}blanktheme>blocksocial_76abe3a162f22f63fae44d60fbe8f11b'] = 'URL Pinterest';
$_MODULE['<{blocksocial}blanktheme>blocksocial_e158a81859319b5e442bc490b0e81af3'] = 'Votre compte officiel Pinterest.';
$_MODULE['<{blocksocial}blanktheme>blocksocial_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blocksocial}blanktheme>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Nous suivre';
$_MODULE['<{blocksocial}blanktheme>blocksocial_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
$_MODULE['<{blocksocial}blanktheme>blocksocial_2491bc9c7d8731e1ae33124093bc7026'] = 'Twitter';
$_MODULE['<{blocksocial}blanktheme>blocksocial_bf1981220040a8ac147698c85d55334f'] = 'RSS';
$_MODULE['<{blocksocial}blanktheme>blocksocial_8dd1bae8da2e2408210d0656fbe6b7d1'] = 'YouTube';
$_MODULE['<{blocksocial}blanktheme>blocksocial_5b2c8bfd1bc974966209b7be1cb51a72'] = 'Google+';
$_MODULE['<{blocksocial}blanktheme>blocksocial_86709a608bd914b28221164e6680ebf7'] = 'Pinterest';
