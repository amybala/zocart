<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homecategories}nella>homecategories_d7749cb903709bfab6d6cf44666c67f2'] = 'NOUVEAUTÉS';
$_MODULE['<{homecategories}nella>homecategories_3bdf43cde5506863115c78c4e386731a'] = 'BEST SELLER';
$_MODULE['<{homecategories}nella>homecategories_053504e87e5a44e90c0b80dce3e4ec78'] = 'LA PLUPART DES AVIS';
$_MODULE['<{homecategories}nella>homecategories_home_d7749cb903709bfab6d6cf44666c67f2'] = 'NOUVEAUTÉS';
$_MODULE['<{homecategories}nella>homecategories_home_3bdf43cde5506863115c78c4e386731a'] = 'BEST SELLER';
$_MODULE['<{homecategories}nella>homecategories_home_053504e87e5a44e90c0b80dce3e4ec78'] = 'LA PLUPART DES AVIS';
