<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}blanktheme>homefeatured_5d17bf499a1b9b2e816c99eebf0153a9'] = 'Produits mis en avant sur la page d\'accueil';
$_MODULE['<{homefeatured}blanktheme>homefeatured_6d37ec35b5b6820f90394e5ee49e8cec'] = 'Affiche vos produits phares dans la colonne centrale de votre page d\'accueil.';
$_MODULE['<{homefeatured}blanktheme>homefeatured_6af91e35dff67a43ace060d1d57d5d1a'] = 'Paramètres mis à jour';
$_MODULE['<{homefeatured}blanktheme>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{homefeatured}blanktheme>homefeatured_d44168e17d91bac89aab3f38d8a4da8e'] = 'Nombre de produits à afficher';
$_MODULE['<{homefeatured}blanktheme>homefeatured_1b73f6b70a0fcd38bbc6a6e4b67e3010'] = 'Indiquez le nombre de produits que vous voulez voir affichés sur la page d\'accueil (par défaut : 8).';
$_MODULE['<{homefeatured}blanktheme>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{homefeatured}blanktheme>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Produits phares';
$_MODULE['<{homefeatured}blanktheme>homefeatured_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_MODULE['<{homefeatured}blanktheme>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Détails';
$_MODULE['<{homefeatured}blanktheme>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Afficher';
$_MODULE['<{homefeatured}blanktheme>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{homefeatured}blanktheme>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Aucun produit phare';
$_MODULE['<{homefeatured}blanktheme>tab_2cc1943d4c0b46bfcf503a75c44f988b'] = 'Populaire';
