<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{groupcategory}blanktheme>groupcategory_4c957e41cb0c8ddabe9064e2856f3ef2'] = 'Most View fr';
$_MODULE['<{groupcategory}blanktheme>groupcategory_d1aa22a3126f04664e0fe3f598994014'] = 'Specials fr';
$_MODULE['<{groupcategory}blanktheme>groupcategory_31d26a6487e08357bd771619e894b0c6'] = 'New Arrivals fr';
$_MODULE['<{groupcategory}blanktheme>groupcategory_c3ae9f07ec41596ed7759c55b9eb77db'] = 'Layout fr';
