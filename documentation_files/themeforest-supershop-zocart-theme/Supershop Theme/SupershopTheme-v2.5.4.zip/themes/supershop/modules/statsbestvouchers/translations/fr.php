<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_58ef962a87e6fbbea6027c17a954a18d'] = 'Enregistrement vide renvoyé.';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_ca0dbad92a874b2f69b549293387925e'] = 'Code';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_df25596dc94d556af2f1823725118572'] = 'Total utilisé';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_b769cee333527b8dc6f3f67882e35a0b'] = 'Meilleurs coupons de réduction';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_d32edaf4608c91c5795eceaa1948aea7'] = 'Ajoute une liste des meilleurs coupons de réduction sur votre tableau de bord des statistiques.';
$_MODULE['<{statsbestvouchers}blanktheme>statsbestvouchers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
