<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{imagesearch}nella>imagesearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{imagesearch}nella>imagesearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Ajoute un bloc avec un champ de recherche rapide';
$_MODULE['<{imagesearch}nella>imagesearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{imagesearch}nella>imagesearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Rechercher un produit';
$_MODULE['<{imagesearch}nella>imagesearch_5f075ae3e1f9d0382bb8c4632991f96f'] = 'Go';
