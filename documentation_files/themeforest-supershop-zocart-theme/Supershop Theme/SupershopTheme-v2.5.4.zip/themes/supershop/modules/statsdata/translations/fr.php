<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsdata}blanktheme>statsdata_a51950bf91ba55cd93a33ce3f8d448c2'] = 'Récupération des données statistiques';
$_MODULE['<{statsdata}blanktheme>statsdata_c77dfd683d0d76940e5e04cb24e8bce1'] = 'Ce module doit être activé pour bénéficier des statistiques.';
$_MODULE['<{statsdata}blanktheme>statsdata_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{statsdata}blanktheme>statsdata_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{statsdata}blanktheme>statsdata_1a5b75c4be3c0100c99764b21e844cc8'] = 'Enregistrer les pages vues pour chaque client';
$_MODULE['<{statsdata}blanktheme>statsdata_73d55f0a158656cbfabab45a3e151d73'] = 'Stocker le nombre de page vues des clients peut se révéler très consommateur en espace disque et en processeur. N\'activez cette option que si votre serveur peut tenir la charge.';
$_MODULE['<{statsdata}blanktheme>statsdata_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{statsdata}blanktheme>statsdata_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{statsdata}blanktheme>statsdata_dd8289e220ec0de9a8b99adc7f9014b1'] = 'Enregistrer les pages vues globales';
$_MODULE['<{statsdata}blanktheme>statsdata_339acfd90b82e91ce9141ec75e4bff24'] = 'Les pages vues nécessitent moins de ressources que le détail par client, mais en nécessitent néanmoins une certaine quantité.';
$_MODULE['<{statsdata}blanktheme>statsdata_c0e4406117ba4c29c4d66e3069ebf3d3'] = 'Détection des plug-ins';
$_MODULE['<{statsdata}blanktheme>statsdata_e4af29282b3a403c2b23c2a516bba889'] = 'La détection des extensions de navigateur charge un fichier JavaScript de 20 ko pour chaque nouveau visiteur (une seule fois).';
$_MODULE['<{statsdata}blanktheme>statsdata_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
